import {InputText} from 'primereact/inputtext'

import React from 'react';

const TextInput = (props) => {
  return (
      <>
        <InputText {...props}/>
      </>
  )
};

export default TextInput;
